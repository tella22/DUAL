
public interface IpilaDeEnteros {
	void push(Integer elemento); // apilar un elemento
	Integer pop(); // desapilar un elemento
}
